//
//  main.cpp
//  Week 2 Project
//
//  Created by Patariki on 11/9/17.
//  Copyright © 2017 Patariki. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
