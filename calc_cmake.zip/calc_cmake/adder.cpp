// calc_cmake/adder.cpp ---------------------------------
#include "adder.h"
int add( int a, int b ) {
    return a + b; }
// /calc_cmake/adder.cpp --------------------------------
